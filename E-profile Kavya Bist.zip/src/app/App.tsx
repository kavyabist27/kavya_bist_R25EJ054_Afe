import { useState, useEffect, useRef, type CSSProperties } from "react";
import {
  Sun, Moon, Mail, Github, Linkedin, Download,
  ExternalLink, Menu, X, Cpu, Code2, Wrench,
  ChevronDown, Lock, Layers, GitBranch, Zap,
} from "lucide-react";

// ─── THEME ────────────────────────────────────────────────────────────────────

const dark = {
  bg: "#0D1117",
  surface: "#161B22",
  surface2: "#21262D",
  border: "rgba(48,54,61,0.9)",
  borderAccent: "#58A6FF",
  text: "#E6EDF3",
  textMuted: "#8B949E",
  textFaint: "#6E7681",
  blue: "#58A6FF",
  blueBg: "rgba(88,166,255,0.10)",
  blueBorder: "rgba(88,166,255,0.28)",
  purpleBg: "rgba(188,140,255,0.10)",
  purpleBorder: "rgba(188,140,255,0.28)",
  tealBg: "rgba(56,189,248,0.10)",
  tealBorder: "rgba(56,189,248,0.28)",
  blueText: "#58A6FF",
  purpleText: "#BC8CFF",
  tealText: "#38BDF8",
  navBg: "rgba(13,17,23,0.90)",
  cardGlow: "rgba(56,139,253,0.08)",
  gradientName: "linear-gradient(135deg, #58A6FF 0%, #BC8CFF 100%)",
  heroBg: "#0D1117",
  dotColor: "rgba(48,54,61,0.55)",
  accentLine: "#58A6FF",
};

const light = {
  bg: "#F1F5FB",
  surface: "#FFFFFF",
  surface2: "#F8FAFC",
  border: "rgba(226,232,240,1)",
  borderAccent: "#2563EB",
  text: "#0F172A",
  textMuted: "#475569",
  textFaint: "#94A3B8",
  blue: "#2563EB",
  blueBg: "rgba(37,99,235,0.07)",
  blueBorder: "rgba(37,99,235,0.22)",
  purpleBg: "rgba(124,58,237,0.07)",
  purpleBorder: "rgba(124,58,237,0.22)",
  tealBg: "rgba(14,165,233,0.07)",
  tealBorder: "rgba(14,165,233,0.22)",
  blueText: "#1D4ED8",
  purpleText: "#6D28D9",
  tealText: "#0369A1",
  navBg: "rgba(241,245,251,0.90)",
  cardGlow: "rgba(37,99,235,0.06)",
  gradientName: "linear-gradient(135deg, #2563EB 0%, #7C3AED 100%)",
  heroBg: "#F1F5FB",
  dotColor: "rgba(203,213,225,0.7)",
  accentLine: "#2563EB",
};

type Theme = typeof dark;

// ─── CSS ──────────────────────────────────────────────────────────────────────

const GLOBAL_CSS = `
  *, *::before, *::after { box-sizing: border-box; }
  html { scroll-behavior: smooth; }
  body { margin: 0; }
  ::-webkit-scrollbar { width: 5px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: rgba(88,166,255,0.25); border-radius: 10px; }
  ::-webkit-scrollbar-thumb:hover { background: rgba(88,166,255,0.45); }

  .kb-nav-link {
    position: relative;
    transition: color 0.2s;
    text-decoration: none;
  }
  .kb-nav-link::after {
    content: '';
    position: absolute;
    bottom: -3px;
    left: 0;
    width: 0;
    height: 1.5px;
    transition: width 0.25s ease;
    background: var(--kb-blue);
  }
  .kb-nav-link:hover::after { width: 100%; }
  .kb-nav-link:hover { color: var(--kb-blue) !important; }

  .kb-card {
    transition: transform 0.25s ease, border-color 0.25s ease, box-shadow 0.25s ease;
    cursor: default;
  }
  .kb-card:hover {
    transform: translateY(-4px);
    border-color: var(--kb-blue) !important;
    box-shadow: 0 12px 40px var(--kb-glow);
  }

  .kb-skill-tag {
    transition: transform 0.15s ease;
    cursor: default;
    user-select: none;
  }
  .kb-skill-tag:hover { transform: translateY(-2px); }

  .kb-btn-primary {
    transition: filter 0.2s ease, transform 0.2s ease;
    cursor: pointer;
    border: none;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  .kb-btn-primary:hover { filter: brightness(1.15); transform: translateY(-2px); }

  .kb-btn-outline {
    transition: background 0.2s ease, transform 0.2s ease, border-color 0.2s ease;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  .kb-btn-outline:hover { transform: translateY(-2px); background: var(--kb-surface2) !important; }

  .kb-icon-btn {
    transition: border-color 0.2s ease, color 0.2s ease, transform 0.2s ease, background 0.2s ease;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 10px;
  }
  .kb-icon-btn:hover {
    border-color: var(--kb-blue) !important;
    color: var(--kb-blue) !important;
    transform: translateY(-3px);
    background: var(--kb-blue-bg) !important;
  }

  .kb-section {
    opacity: 0;
    transform: translateY(24px);
    transition: opacity 0.65s cubic-bezier(0.16,1,0.3,1), transform 0.65s cubic-bezier(0.16,1,0.3,1);
  }
  .kb-section.visible { opacity: 1; transform: translateY(0); }

  .kb-dot-grid {
    background-image: radial-gradient(circle, var(--kb-dot) 1px, transparent 1px);
    background-size: 28px 28px;
  }

  @keyframes kb-up {
    from { opacity: 0; transform: translateY(28px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  .kb-a1 { opacity: 0; animation: kb-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.05s forwards; }
  .kb-a2 { opacity: 0; animation: kb-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.18s forwards; }
  .kb-a3 { opacity: 0; animation: kb-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.32s forwards; }
  .kb-a4 { opacity: 0; animation: kb-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.48s forwards; }
  .kb-a5 { opacity: 0; animation: kb-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.64s forwards; }

  @keyframes kb-pulse-dot {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
  }
  .kb-pulse { animation: kb-pulse-dot 2.2s ease-in-out infinite; }

  .kb-menu-item {
    transition: color 0.2s, background 0.2s;
    border-radius: 6px;
  }
  .kb-menu-item:hover { background: var(--kb-surface2); color: var(--kb-blue) !important; }

  .kb-gradient-text {
    background: var(--kb-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
`;

// ─── HOOKS ────────────────────────────────────────────────────────────────────

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

// ─── SUB-COMPONENTS ───────────────────────────────────────────────────────────

function SectionLabel({ t, children }: { t: Theme; children: React.ReactNode }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
      <span style={{ display: "block", width: "20px", height: "2px", background: t.blue, borderRadius: "2px", flexShrink: 0 }} />
      <span style={{ fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.16em", textTransform: "uppercase", color: t.blue }}>
        {children}
      </span>
    </div>
  );
}

function SkillTag({
  label,
  bg,
  border,
  color,
}: {
  label: string;
  bg: string;
  border: string;
  color: string;
}) {
  return (
    <span
      className="kb-skill-tag"
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "5px 13px",
        borderRadius: "20px",
        fontSize: "0.78rem",
        fontWeight: 500,
        background: bg,
        border: `1px solid ${border}`,
        color,
        lineHeight: 1.4,
      }}
    >
      {label}
    </span>
  );
}

function ProjectCard({
  t,
  num,
  title,
  description,
  stack,
  accentColor,
  icon,
}: {
  t: Theme;
  num: string;
  title: string;
  description: string;
  stack: string[];
  accentColor: string;
  icon: React.ReactNode;
}) {
  return (
    <div
      className="kb-card"
      style={{
        background: t.surface,
        border: `1px solid ${t.border}`,
        borderRadius: "12px",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Accent bar */}
      <div
        style={{
          height: "3px",
          background: accentColor,
          flexShrink: 0,
        }}
      />
      <div style={{ padding: "28px 28px 24px" }}>
        {/* Header row */}
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "16px", gap: "12px" }}>
          <div>
            <span
              style={{
                display: "block",
                fontSize: "0.7rem",
                fontWeight: 600,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: t.textFaint,
                marginBottom: "6px",
              }}
            >
              Project {num}
            </span>
            <h3
              style={{
                margin: 0,
                fontSize: "1.15rem",
                fontWeight: 700,
                color: t.text,
                lineHeight: 1.3,
              }}
            >
              {title}
            </h3>
          </div>
          <span
            style={{
              flexShrink: 0,
              width: "40px",
              height: "40px",
              borderRadius: "10px",
              background: `${accentColor}18`,
              border: `1px solid ${accentColor}35`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: accentColor,
            }}
          >
            {icon}
          </span>
        </div>

        {/* Description */}
        <p
          style={{
            margin: "0 0 20px",
            fontSize: "0.875rem",
            lineHeight: 1.75,
            color: t.textMuted,
            fontWeight: 400,
          }}
        >
          {description}
        </p>

        {/* Stack tags */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "24px" }}>
          {stack.map((s) => (
            <span
              key={s}
              style={{
                padding: "3px 10px",
                borderRadius: "4px",
                fontSize: "0.72rem",
                fontWeight: 600,
                letterSpacing: "0.04em",
                background: t.surface2,
                border: `1px solid ${t.border}`,
                color: t.textMuted,
                fontFamily: "monospace",
              }}
            >
              {s}
            </span>
          ))}
        </div>

        {/* Link */}
        <a
          href="#"
          className="kb-btn-outline"
          style={{
            padding: "8px 16px",
            borderRadius: "8px",
            fontSize: "0.78rem",
            fontWeight: 600,
            letterSpacing: "0.03em",
            background: "transparent",
            border: `1px solid ${t.border}`,
            color: t.text,
          }}
          onClick={(e) => e.preventDefault()}
        >
          <ExternalLink size={13} />
          View Project
        </a>
      </div>
    </div>
  );
}

function RevealSection({
  children,
  delay = "0s",
}: {
  children: React.ReactNode;
  delay?: string;
}) {
  const { ref, visible } = useReveal();
  return (
    <div
      ref={ref}
      className={`kb-section${visible ? " visible" : ""}`}
      style={{ transitionDelay: visible ? delay : "0s" }}
    >
      {children}
    </div>
  );
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [isDark, setIsDark] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const t = isDark ? dark : light;

  useEffect(() => {
    const fn = () => {
      setScrolled(window.scrollY > 50);
      if (menuOpen) setMenuOpen(false);
    };
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, [menuOpen]);

  const cssVars = {
    "--kb-blue": t.blue,
    "--kb-surface2": t.surface2,
    "--kb-glow": t.cardGlow,
    "--kb-dot": t.dotColor,
    "--kb-gradient": t.gradientName,
    "--kb-blue-bg": t.blueBg,
  } as CSSProperties;

  const navLinks = ["About", "Skills", "Projects", "Contact"];

  return (
    <>
      <style>{GLOBAL_CSS}</style>
      <div
        style={{
          ...cssVars,
          background: t.bg,
          color: t.text,
          minHeight: "100vh",
          fontFamily: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
          transition: "background 0.35s ease, color 0.35s ease",
        }}
      >

        {/* ── NAV ── */}
        <nav
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            zIndex: 100,
            background: scrolled ? t.navBg : "transparent",
            backdropFilter: scrolled ? "blur(14px) saturate(1.4)" : "none",
            borderBottom: scrolled ? `1px solid ${t.border}` : "1px solid transparent",
            transition: "background 0.35s ease, backdrop-filter 0.35s ease, border-color 0.35s ease",
          }}
        >
          <div
            style={{
              maxWidth: "1160px",
              margin: "0 auto",
              padding: "0 24px",
              height: "64px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            {/* Logo */}
            <a
              href="#hero"
              style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: "10px" }}
            >
              <span
                style={{
                  width: "34px",
                  height: "34px",
                  borderRadius: "8px",
                  background: t.gradientName,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "0.8rem",
                  fontWeight: 800,
                  color: "#fff",
                  letterSpacing: "-0.02em",
                  flexShrink: 0,
                }}
              >
                KB
              </span>
              <span
                style={{
                  fontSize: "0.9rem",
                  fontWeight: 700,
                  color: t.text,
                  letterSpacing: "-0.01em",
                  display: "none",
                }}
                className="kb-wordmark"
              >
                Kavya Bist
              </span>
            </a>

            {/* Desktop links */}
            <div style={{ display: "flex", alignItems: "center", gap: "32px" }}>
              {navLinks.map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  className="kb-nav-link"
                  style={{
                    fontSize: "0.85rem",
                    fontWeight: 500,
                    color: t.textMuted,
                    display: window.innerWidth < 640 ? "none" : "block",
                  }}
                >
                  {link}
                </a>
              ))}

              {/* Theme toggle */}
              <button
                onClick={() => setIsDark(!isDark)}
                aria-label="Toggle theme"
                style={{
                  background: t.surface2,
                  border: `1px solid ${t.border}`,
                  borderRadius: "8px",
                  width: "36px",
                  height: "36px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  color: t.textMuted,
                  transition: "background 0.2s, border-color 0.2s",
                  flexShrink: 0,
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = t.blue;
                  (e.currentTarget as HTMLButtonElement).style.color = t.blue;
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = t.border;
                  (e.currentTarget as HTMLButtonElement).style.color = t.textMuted;
                }}
              >
                {isDark ? <Sun size={16} /> : <Moon size={16} />}
              </button>

              {/* Mobile hamburger */}
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                aria-label="Toggle menu"
                style={{
                  background: "transparent",
                  border: "none",
                  cursor: "pointer",
                  color: t.textMuted,
                  padding: "4px",
                  display: "none",
                }}
                className="kb-hamburger"
              >
                {menuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>

          {/* Mobile menu */}
          {menuOpen && (
            <div
              style={{
                background: t.surface,
                borderTop: `1px solid ${t.border}`,
                padding: "16px 24px 20px",
                display: "flex",
                flexDirection: "column",
                gap: "4px",
              }}
            >
              {navLinks.map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  onClick={() => setMenuOpen(false)}
                  className="kb-menu-item"
                  style={{
                    fontSize: "0.9rem",
                    fontWeight: 500,
                    color: t.textMuted,
                    padding: "10px 12px",
                    textDecoration: "none",
                    display: "block",
                  }}
                >
                  {link}
                </a>
              ))}
            </div>
          )}
        </nav>

        {/* ── HERO ── */}
        <section
          id="hero"
          className="kb-dot-grid"
          style={{
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            padding: "120px 24px 80px",
            position: "relative",
            background: t.heroBg,
          }}
        >
          {/* Glow */}
          <div
            style={{
              position: "absolute",
              top: "0",
              left: "50%",
              transform: "translateX(-50%)",
              width: "700px",
              height: "400px",
              background: isDark
                ? "radial-gradient(ellipse at 50% 0%, rgba(56,139,253,0.18) 0%, transparent 65%)"
                : "radial-gradient(ellipse at 50% 0%, rgba(37,99,235,0.10) 0%, transparent 65%)",
              pointerEvents: "none",
            }}
          />

          <div style={{ position: "relative", maxWidth: "780px", width: "100%" }}>
            {/* Status badge */}
            <div className="kb-a1" style={{ display: "flex", justifyContent: "center", marginBottom: "28px" }}>
              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "7px",
                  padding: "6px 14px",
                  borderRadius: "20px",
                  fontSize: "0.75rem",
                  fontWeight: 600,
                  background: t.blueBg,
                  border: `1px solid ${t.blueBorder}`,
                  color: t.blueText,
                  letterSpacing: "0.04em",
                }}
              >
                <span
                  className="kb-pulse"
                  style={{
                    width: "7px",
                    height: "7px",
                    borderRadius: "50%",
                    background: t.blue,
                    display: "inline-block",
                    flexShrink: 0,
                  }}
                />
                Available for Internships & Projects
              </span>
            </div>

            {/* Name */}
            <h1
              className="kb-a2 kb-gradient-text"
              style={{
                fontSize: "clamp(3rem, 8vw, 5.5rem)",
                fontWeight: 800,
                margin: "0 0 16px",
                letterSpacing: "-0.04em",
                lineHeight: 1.05,
              }}
            >
              Kavya Bist
            </h1>

            {/* Title */}
            <p
              className="kb-a3"
              style={{
                fontSize: "clamp(0.95rem, 2.5vw, 1.15rem)",
                fontWeight: 500,
                color: t.textMuted,
                margin: "0 0 28px",
                letterSpacing: "-0.01em",
              }}
            >
              Computer Science & IT Student{" "}
              <span style={{ color: t.border, margin: "0 6px" }}>·</span>
              Embedded Systems & AI Enthusiast
            </p>

            {/* Hero statement */}
            <p
              className="kb-a4"
              style={{
                fontSize: "clamp(0.9rem, 2vw, 1.05rem)",
                lineHeight: 1.8,
                color: t.textMuted,
                fontWeight: 300,
                margin: "0 auto 44px",
                maxWidth: "620px",
              }}
            >
              I bridge the gap between hardware and software, focusing on digital
              electronics, IoT architecture, and intelligent systems. Currently
              pursuing my degree in CSIT, I build robust applications from the
              register level up to the cloud.
            </p>

            {/* CTAs */}
            <div
              className="kb-a5"
              style={{
                display: "flex",
                gap: "14px",
                justifyContent: "center",
                flexWrap: "wrap",
              }}
            >
              <a
                href="#projects"
                className="kb-btn-primary"
                style={{
                  padding: "12px 26px",
                  borderRadius: "10px",
                  fontSize: "0.875rem",
                  fontWeight: 700,
                  background: t.gradientName,
                  color: "#fff",
                  letterSpacing: "0.02em",
                }}
              >
                View Projects
                <ChevronDown size={15} />
              </a>
              <a
                href="#"
                className="kb-btn-outline"
                style={{
                  padding: "12px 26px",
                  borderRadius: "10px",
                  fontSize: "0.875rem",
                  fontWeight: 600,
                  background: t.surface,
                  border: `1px solid ${t.border}`,
                  color: t.text,
                  letterSpacing: "0.02em",
                }}
                onClick={(e) => e.preventDefault()}
              >
                <Download size={15} />
                Download Resume
              </a>
            </div>
          </div>

          {/* Scroll hint */}
          <div
            style={{
              position: "absolute",
              bottom: "32px",
              left: "50%",
              transform: "translateX(-50%)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "6px",
              color: t.textFaint,
            }}
          >
            <span style={{ fontSize: "0.65rem", letterSpacing: "0.15em", textTransform: "uppercase", fontWeight: 600 }}>
              Scroll
            </span>
            <ChevronDown size={14} className="kb-pulse" />
          </div>
        </section>

        {/* ── ABOUT ── */}
        <section
          id="about"
          style={{
            padding: "100px 24px",
            borderTop: `1px solid ${t.border}`,
          }}
        >
          <div style={{ maxWidth: "1160px", margin: "0 auto" }}>
            <RevealSection>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 420px), 1fr))",
                  gap: "60px",
                  alignItems: "start",
                }}
              >
                {/* Left: narrative */}
                <div>
                  <SectionLabel t={t}>About Me</SectionLabel>
                  <h2
                    style={{
                      fontSize: "clamp(1.6rem, 4vw, 2.2rem)",
                      fontWeight: 800,
                      color: t.text,
                      margin: "0 0 20px",
                      letterSpacing: "-0.03em",
                      lineHeight: 1.2,
                    }}
                  >
                    Hardware logic meets software intelligence.
                  </h2>
                  <p
                    style={{
                      fontSize: "0.95rem",
                      lineHeight: 1.85,
                      color: t.textMuted,
                      fontWeight: 300,
                      margin: "0 0 20px",
                    }}
                  >
                    I am deeply passionate about understanding how digital logic
                    drives the modern software stack. From the fundamental gates
                    that underpin every CPU to the cloud architectures that scale
                    across continents, I find meaning at every layer of
                    abstraction.
                  </p>
                  <p
                    style={{
                      fontSize: "0.95rem",
                      lineHeight: 1.85,
                      color: t.textMuted,
                      fontWeight: 300,
                      margin: 0,
                    }}
                  >
                    My academic foundation spans core computer science theory,
                    logical systems design, and hands-on hardware-software
                    integration — with a particular focus on embedded security
                    and IoT architecture, where the physical and digital worlds
                    converge.
                  </p>
                </div>

                {/* Right: academic card */}
                <div>
                  <SectionLabel t={t}>Academic Profile</SectionLabel>
                  <div
                    style={{
                      background: t.surface,
                      border: `1px solid ${t.border}`,
                      borderRadius: "14px",
                      overflow: "hidden",
                    }}
                  >
                    {/* Card header */}
                    <div
                      style={{
                        padding: "20px 24px",
                        background: isDark
                          ? "linear-gradient(135deg, rgba(56,139,253,0.12) 0%, rgba(188,140,255,0.08) 100%)"
                          : "linear-gradient(135deg, rgba(37,99,235,0.07) 0%, rgba(124,58,237,0.05) 100%)",
                        borderBottom: `1px solid ${t.border}`,
                        display: "flex",
                        alignItems: "center",
                        gap: "14px",
                      }}
                    >
                      <span
                        style={{
                          width: "42px",
                          height: "42px",
                          borderRadius: "10px",
                          background: t.gradientName,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}
                      >
                        <Layers size={20} color="#fff" />
                      </span>
                      <div>
                        <p style={{ margin: 0, fontSize: "0.72rem", fontWeight: 600, color: t.textFaint, letterSpacing: "0.1em", textTransform: "uppercase" }}>
                          Degree Programme
                        </p>
                        <p style={{ margin: "2px 0 0", fontSize: "0.9rem", fontWeight: 700, color: t.text, lineHeight: 1.3 }}>
                          B.Tech — Computer Science & IT
                        </p>
                      </div>
                    </div>

                    {/* Details */}
                    {[
                      { label: "Full Programme", value: "Bachelor of Technology in Computer Science & Information Technology (CSIT)" },
                      { label: "Class Section", value: "CSIT-A" },
                      { label: "Registration No.", value: "R25EJ054", mono: true },
                    ].map((row, i) => (
                      <div
                        key={i}
                        style={{
                          padding: "14px 24px",
                          display: "flex",
                          flexDirection: "column",
                          gap: "3px",
                          borderBottom: i < 2 ? `1px solid ${t.border}` : "none",
                        }}
                      >
                        <span style={{ fontSize: "0.68rem", fontWeight: 600, color: t.textFaint, letterSpacing: "0.1em", textTransform: "uppercase" }}>
                          {row.label}
                        </span>
                        <span
                          style={{
                            fontSize: row.mono ? "0.875rem" : "0.88rem",
                            fontWeight: row.mono ? 600 : 500,
                            color: row.mono ? t.blue : t.text,
                            fontFamily: row.mono ? "'Courier New', monospace" : "inherit",
                            letterSpacing: row.mono ? "0.06em" : "normal",
                          }}
                        >
                          {row.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </RevealSection>
          </div>
        </section>

        {/* ── SKILLS ── */}
        <section
          id="skills"
          style={{
            padding: "100px 24px",
            background: isDark
              ? "linear-gradient(180deg, #0D1117 0%, #111827 100%)"
              : "linear-gradient(180deg, #F1F5FB 0%, #E8EFF8 100%)",
            borderTop: `1px solid ${t.border}`,
            borderBottom: `1px solid ${t.border}`,
          }}
        >
          <div style={{ maxWidth: "1160px", margin: "0 auto" }}>
            <RevealSection>
              <div style={{ textAlign: "center", marginBottom: "60px" }}>
                <SectionLabel t={t}>
                  <span style={{ display: "flex", justifyContent: "center" }}>Technical Skills</span>
                </SectionLabel>
                <h2
                  style={{
                    fontSize: "clamp(1.6rem, 4vw, 2.2rem)",
                    fontWeight: 800,
                    color: t.text,
                    margin: "0 auto",
                    letterSpacing: "-0.03em",
                    lineHeight: 1.2,
                    maxWidth: "500px",
                  }}
                >
                  Tools, Languages & Domains
                </h2>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 300px), 1fr))",
                  gap: "24px",
                }}
              >
                {/* Core Languages */}
                <div
                  className="kb-card"
                  style={{
                    background: t.surface,
                    border: `1px solid ${t.border}`,
                    borderRadius: "14px",
                    padding: "26px",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "20px" }}>
                    <span
                      style={{
                        width: "38px",
                        height: "38px",
                        borderRadius: "9px",
                        background: t.blueBg,
                        border: `1px solid ${t.blueBorder}`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: t.blueText,
                        flexShrink: 0,
                      }}
                    >
                      <Code2 size={18} />
                    </span>
                    <div>
                      <h3 style={{ margin: 0, fontSize: "0.95rem", fontWeight: 700, color: t.text }}>Core Languages</h3>
                      <p style={{ margin: 0, fontSize: "0.72rem", color: t.textFaint, fontWeight: 400 }}>Programming foundations</p>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                    <SkillTag label="C Programming" bg={t.blueBg} border={t.blueBorder} color={t.blueText} />
                    <SkillTag label="C++" bg={t.blueBg} border={t.blueBorder} color={t.blueText} />
                    <SkillTag label="Python" bg={t.blueBg} border={t.blueBorder} color={t.blueText} />
                    <SkillTag label="Pointer & Array Mastery" bg={t.blueBg} border={t.blueBorder} color={t.blueText} />
                    <SkillTag label="Memory Layout Design" bg={t.blueBg} border={t.blueBorder} color={t.blueText} />
                    <SkillTag label="Structural Logic" bg={t.blueBg} border={t.blueBorder} color={t.blueText} />
                  </div>
                </div>

                {/* Hardware & IoT */}
                <div
                  className="kb-card"
                  style={{
                    background: t.surface,
                    border: `1px solid ${t.border}`,
                    borderRadius: "14px",
                    padding: "26px",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "20px" }}>
                    <span
                      style={{
                        width: "38px",
                        height: "38px",
                        borderRadius: "9px",
                        background: t.purpleBg,
                        border: `1px solid ${t.purpleBorder}`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: t.purpleText,
                        flexShrink: 0,
                      }}
                    >
                      <Cpu size={18} />
                    </span>
                    <div>
                      <h3 style={{ margin: 0, fontSize: "0.95rem", fontWeight: 700, color: t.text }}>Hardware & IoT</h3>
                      <p style={{ margin: 0, fontSize: "0.72rem", color: t.textFaint, fontWeight: 400 }}>Embedded & physical computing</p>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                    <SkillTag label="Digital Electronics" bg={t.purpleBg} border={t.purpleBorder} color={t.purpleText} />
                    <SkillTag label="ESP32" bg={t.purpleBg} border={t.purpleBorder} color={t.purpleText} />
                    <SkillTag label="Arduino" bg={t.purpleBg} border={t.purpleBorder} color={t.purpleText} />
                    <SkillTag label="Circuit Logic" bg={t.purpleBg} border={t.purpleBorder} color={t.purpleText} />
                    <SkillTag label="I2C Protocol" bg={t.purpleBg} border={t.purpleBorder} color={t.purpleText} />
                    <SkillTag label="SPI Protocol" bg={t.purpleBg} border={t.purpleBorder} color={t.purpleText} />
                    <SkillTag label="Microcontrollers" bg={t.purpleBg} border={t.purpleBorder} color={t.purpleText} />
                  </div>
                </div>

                {/* Concepts & Tools */}
                <div
                  className="kb-card"
                  style={{
                    background: t.surface,
                    border: `1px solid ${t.border}`,
                    borderRadius: "14px",
                    padding: "26px",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "20px" }}>
                    <span
                      style={{
                        width: "38px",
                        height: "38px",
                        borderRadius: "9px",
                        background: t.tealBg,
                        border: `1px solid ${t.tealBorder}`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: t.tealText,
                        flexShrink: 0,
                      }}
                    >
                      <Wrench size={18} />
                    </span>
                    <div>
                      <h3 style={{ margin: 0, fontSize: "0.95rem", fontWeight: 700, color: t.text }}>Concepts & Tools</h3>
                      <p style={{ margin: 0, fontSize: "0.72rem", color: t.textFaint, fontWeight: 400 }}>CS fundamentals & tooling</p>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                    <SkillTag label="Algorithm Design" bg={t.tealBg} border={t.tealBorder} color={t.tealText} />
                    <SkillTag label="Embedded Security" bg={t.tealBg} border={t.tealBorder} color={t.tealText} />
                    <SkillTag label="Git / GitHub" bg={t.tealBg} border={t.tealBorder} color={t.tealText} />
                    <SkillTag label="Computer Architecture" bg={t.tealBg} border={t.tealBorder} color={t.tealText} />
                    <SkillTag label="Logic Gate Design" bg={t.tealBg} border={t.tealBorder} color={t.tealText} />
                  </div>
                </div>
              </div>
            </RevealSection>
          </div>
        </section>

        {/* ── PROJECTS ── */}
        <section
          id="projects"
          style={{ padding: "100px 24px", borderBottom: `1px solid ${t.border}` }}
        >
          <div style={{ maxWidth: "1160px", margin: "0 auto" }}>
            <RevealSection>
              <div style={{ marginBottom: "52px" }}>
                <SectionLabel t={t}>Projects</SectionLabel>
                <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }}>
                  <h2
                    style={{
                      fontSize: "clamp(1.6rem, 4vw, 2.2rem)",
                      fontWeight: 800,
                      color: t.text,
                      margin: 0,
                      letterSpacing: "-0.03em",
                      lineHeight: 1.2,
                    }}
                  >
                    What I&apos;ve Built
                  </h2>
                  <span
                    style={{
                      fontSize: "0.78rem",
                      fontWeight: 500,
                      color: t.textFaint,
                      fontFamily: "monospace",
                      letterSpacing: "0.05em",
                    }}
                  >
                    2 featured projects
                  </span>
                </div>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 460px), 1fr))",
                  gap: "24px",
                }}
              >
                <ProjectCard
                  t={t}
                  num="01"
                  title="IoT-Based Keypad Security System"
                  description="Designed and implemented a secure access control system using an ESP32 microcontroller. Integrated a 4×4 matrix keypad for passcode entry and an I2C LCD for real-time user feedback and status updates. Focused on debouncing logic, secure state management, and robust peripheral communication protocols."
                  stack={["C", "ESP32", "I2C Protocol", "Embedded Security", "LCD Display", "4×4 Matrix Keypad"]}
                  accentColor={t.blue}
                  icon={<Lock size={18} />}
                />
                <ProjectCard
                  t={t}
                  num="02"
                  title="Digital Electronics in AI — Logic Model"
                  description="Developed a structural breakdown and presentation model showcasing fundamental intersections of hardware logic gates and neural network processing, demonstrating how digital electronics principles underpin physical AI acceleration hardware at the silicon level."
                  stack={["Digital Logic Design", "Computer Architecture", "Gate-Level Modeling", "AI Hardware"]}
                  accentColor={isDark ? "#BC8CFF" : "#7C3AED"}
                  icon={<Zap size={18} />}
                />
              </div>
            </RevealSection>
          </div>
        </section>

        {/* ── CONTACT ── */}
        <section id="contact" style={{ padding: "100px 24px" }}>
          <div style={{ maxWidth: "1160px", margin: "0 auto" }}>
            <RevealSection>
              <div
                style={{
                  background: t.surface,
                  border: `1px solid ${t.border}`,
                  borderRadius: "20px",
                  padding: "clamp(40px, 6vw, 72px)",
                  textAlign: "center",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                {/* Background glow */}
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: "50%",
                    transform: "translateX(-50%)",
                    width: "600px",
                    height: "300px",
                    background: isDark
                      ? "radial-gradient(ellipse at 50% 0%, rgba(56,139,253,0.12) 0%, transparent 60%)"
                      : "radial-gradient(ellipse at 50% 0%, rgba(37,99,235,0.07) 0%, transparent 60%)",
                    pointerEvents: "none",
                  }}
                />

                <div style={{ position: "relative" }}>
                  <SectionLabel t={t}>
                    <span style={{ display: "flex", justifyContent: "center" }}>Get In Touch</span>
                  </SectionLabel>

                  <h2
                    style={{
                      fontSize: "clamp(1.8rem, 5vw, 3rem)",
                      fontWeight: 800,
                      color: t.text,
                      margin: "0 0 16px",
                      letterSpacing: "-0.04em",
                      lineHeight: 1.1,
                    }}
                  >
                    Let&apos;s build something together.
                  </h2>
                  <p
                    style={{
                      fontSize: "0.95rem",
                      color: t.textMuted,
                      fontWeight: 300,
                      margin: "0 auto 44px",
                      maxWidth: "460px",
                      lineHeight: 1.75,
                    }}
                  >
                    Open to internship opportunities, collaborative projects, and
                    conversations about embedded systems, IoT, and AI hardware.
                  </p>

                  {/* Icon links */}
                  <div
                    style={{
                      display: "flex",
                      gap: "14px",
                      justifyContent: "center",
                      flexWrap: "wrap",
                      marginBottom: "36px",
                    }}
                  >
                    {[
                      { href: "mailto:kavya@example.com", icon: <Mail size={18} />, label: "Email" },
                      { href: "https://github.com/", icon: <Github size={18} />, label: "GitHub" },
                      { href: "https://linkedin.com/", icon: <Linkedin size={18} />, label: "LinkedIn" },
                    ].map(({ href, icon, label }) => (
                      <a
                        key={label}
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="kb-icon-btn"
                        style={{
                          padding: "12px 22px",
                          borderRadius: "10px",
                          fontSize: "0.875rem",
                          fontWeight: 600,
                          background: t.surface2,
                          border: `1px solid ${t.border}`,
                          color: t.textMuted,
                          letterSpacing: "0.01em",
                        }}
                      >
                        {icon}
                        {label}
                      </a>
                    ))}
                  </div>

                  {/* Download Resume */}
                  <a
                    href="#"
                    className="kb-btn-primary"
                    style={{
                      padding: "14px 34px",
                      borderRadius: "12px",
                      fontSize: "0.9rem",
                      fontWeight: 700,
                      background: t.gradientName,
                      color: "#fff",
                      letterSpacing: "0.02em",
                    }}
                    onClick={(e) => e.preventDefault()}
                  >
                    <Download size={17} />
                    Download Resume (PDF)
                  </a>
                </div>
              </div>
            </RevealSection>
          </div>
        </section>

        {/* ── FOOTER ── */}
        <footer
          style={{
            borderTop: `1px solid ${t.border}`,
            padding: "28px 24px",
          }}
        >
          <div
            style={{
              maxWidth: "1160px",
              margin: "0 auto",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              flexWrap: "wrap",
              gap: "12px",
            }}
          >
            <span style={{ fontSize: "0.8rem", color: t.textFaint, fontWeight: 400 }}>
              © 2026 Kavya Bist. All rights reserved.
            </span>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <GitBranch size={13} style={{ color: t.textFaint }} />
              <span
                style={{
                  fontSize: "0.72rem",
                  color: t.textFaint,
                  fontFamily: "monospace",
                  letterSpacing: "0.04em",
                }}
              >
                R25EJ054 · CSIT-A
              </span>
            </div>
          </div>
        </footer>

      </div>
    </>
  );
}
